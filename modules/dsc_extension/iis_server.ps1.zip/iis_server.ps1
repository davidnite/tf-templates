Configuration Main
{

Param ( [string] $nodeName )

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
    WindowsFeature WebServerRole
    {
      Name = "Web-Server"
      Ensure = "Present"
    }
    WindowsFeature WebServer
    {
      Name = "Web-WebServer"
      Ensure = "Present"
    }
    WindowsFeature CommonHttpFeatures
    {
      Name = "Web-Common-Http"
      Ensure = "Present"
    }
    WindowsFeature HealthAndDiagnostics
    {
      Name = "Web-Health"
      Ensure = "Present"
    }
    WindowsFeature HttpLogging
    {
      Name = "Web-Http-Logging"
      Ensure = "Present"
    }
    WindowsFeature LoggingTools
    {
      Name = "Web-Log-Libraries"
      Ensure = "Present"
    }
    WindowsFeature Performance
    {
      Name = "Web-Performance"
      Ensure = "Present"
    }
    WindowsFeature StaticCompression
    {
      Name = "Web-Stat-Compression"
      Ensure = "Present"
    }
    WindowsFeature DynamicCompression
    {
      Name = "Web-Dyn-Compression"
      Ensure = "Present"
    }
    WindowsFeature Security
    {
      Name = "Web-Security"
      Ensure = "Present"
    }
    WindowsFeature RequestFiltering
    {
      Name = "Web-Filtering"
      Ensure = "Present"
    }
    WindowsFeature WindowsAuthentication
    {
      Name = "Web-Windows-Auth"
      Ensure = "Present"
    }
    WindowsFeature ApplicationDevelopment
    {
      Name = "Web-App-Dev"
      Ensure = "Present"
    }
    WindowsFeature WebNetExt
    {
      Name = "Web-Net-Ext"
      Ensure = "Present"
    }
    WindowsFeature WebNetExt45
    {
      Name = "Web-Net-Ext45"
      Ensure = "Present"
    }
    WindowsFeature ApplicationInitialization
    {
      Name = "Web-AppInit"
      Ensure = "Present"
    }
    WindowsFeature AspNet
    {
      Name = "Web-Asp-Net"
      Ensure = "Present"
    }
    WindowsFeature ISAPIExtensions
    {
      Name = "Web-ISAPI-Ext"
      Ensure = "Present"
    }
    WindowsFeature ISAPIFilters
    {
      Name = "Web-ISAPI-Filter"
      Ensure = "Present"
    }

    WindowsFeature WebManagementTools
    {
      Name = "Web-Mgmt-Tools"
      Ensure = "Present"
    }
    WindowsFeature WebManagementConsole
    {
      Name = "Web-Mgmt-Console"
      Ensure = "Present"
    }
    WindowsFeature WebManagementCompatibility
    {
      Name = "Web-Mgmt-Compat"
      Ensure = "Present"
    }
    WindowsFeature WebManagementScripts
    {
      Name = "Web-Scripting-Tools"
      Ensure = "Present"
    }
    WindowsFeature WebManagementService
    {
      Name = "Web-Mgmt-Service"
      Ensure = "Present"
    }
  }
}